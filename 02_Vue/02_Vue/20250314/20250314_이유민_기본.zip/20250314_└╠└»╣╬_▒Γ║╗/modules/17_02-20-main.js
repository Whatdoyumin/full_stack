import getBase, { add } from './16_02-19-modules.js';

console.log(add);
console.log(getBase);
