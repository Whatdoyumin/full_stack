import { add } from './13_02-19-module.js';

console.log(add(4));
